# BTC Mobile Signal Dashboard

Phone-friendly Streamlit version of the BTC short-term prediction system.

## Deploy
1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt`.
3. Sign into Streamlit Community Cloud.
4. Create an app from the GitHub repository.
5. Open the resulting `*.streamlit.app` URL on your iPhone.

The dashboard is responsive and centered for a phone screen.

## Important
The confidence is a statistical model output, not a guaranteed probability of winning a trade.
